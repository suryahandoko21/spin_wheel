-- This file should undo anything in `up.sql`
drop table tb_spin_prizes;