pub mod get_all_spin_lists_usecase;
pub mod  find_by_id_usecase;
pub mod post_one_spin_list_usecase;
pub mod delete_by_id_usecase;
pub mod update_one_spin_list_usecase;
pub mod  post_spin_by_uuid;