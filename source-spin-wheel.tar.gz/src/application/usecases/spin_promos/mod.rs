pub mod get_all_spin_promos_usecase;
pub mod post_one_spin_promos;