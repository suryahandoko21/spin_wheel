pub mod spin_prizes_presenters;
pub mod spin_prizes_mappers;
pub mod spin_prizes_payloads;
pub mod spin_prizes_controllers;
