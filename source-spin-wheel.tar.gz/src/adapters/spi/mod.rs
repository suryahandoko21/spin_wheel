pub mod cfg;
pub mod prizes;
pub mod spinlist;
pub mod promos;
pub mod companies;
pub mod spintickets;