pub mod spin_prizes_entity;
pub mod error;
pub mod spin_lists_entity;
pub mod spin_promos_entity;
pub mod spin_tikcets_entity;